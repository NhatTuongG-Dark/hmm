const https = require("https");
const cheerio = require("cheerio");
const _ = require("lodash");
const jsdom = require("jsdom");
const fs = require("fs");

const requestIps = async (ip, savedResult) => {
  const options = {
    hostname: "tools.seo-auditor.com.ru",
    path: "/tools/ip-site/",
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8",
      "Accept": "*/*",
      "X-Requested-With": "XMLHttpRequest",
      "Origin": "https://tools.seo-auditor.com.ru",
      "Referer": "https://tools.seo-auditor.com.ru/ip-site/",
      "Sec-Fetch-Mode": "cors",
      "Sec-Fetch-Site": "same-origin"
    }
  };
  
  const requestBody = `url=${ip}`;
  const domains = [];
  const req = https.request(options, res => {
    console.log("Response status code:", res.statusCode);
    
    res.on("data",async data => {
      // console.log("Response body:", data.toString());
      const htmlResponse = data.toString();
      const text = `${htmlResponse}}`
      const regex = /<td width="90%">(.*?)<\/td>/g;
  
  
      let match;
      while ((match = regex.exec(text))) {
        const domain = match[1];
        domains.push(domain);
        
      }
      console.log(domains)
      fs.writeFile(`result/${ip}-domains.txt`, domains.join("\n"), err => {
        if (err) {
          console.error("Error writing file:", err);
        } else {
          console.log("Domains saved to file: ", `${ip}-domains.txt`);
          const fileContent = fs.readFileSync(`result/${ip}-domains.txt`, 'utf8');
  
          // Append the file content to the merged file
          fs.appendFileSync(savedResult, fileContent);
        }
      });
    });
  });
  
  req.on("error", error => {
    console.error("Request error:", error);
  });
  
  req.write(requestBody);
  
  req.end();  
}


module.exports = requestIps;