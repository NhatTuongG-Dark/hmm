
const readline = require('readline');
const figlet = require('figlet');
const readBulkIp = require('./readBulkIP.js');
const requestIps = require('./requestIps.js');
const fs = require('fs');
const txtMerger = require('./txtMerger.js');

const ipAddressRegex = /\b\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}\b/g;

figlet("     Caterscam", async function (err, data) {
  if (err) {
    console.log("Something went wrong...");
    console.dir(err);
    return;
  }
  await console.log(data);
});


const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

setTimeout(() => {
  console.log('\033[97m\033[101m\033[97m[ powerfull reverse ip by node js coder by t.me/devonaji ]\033[0m\n\n');
  rl.question('[+] input ips file : ', async (text) => {

      const results = [];
      console.log(`\nIPs from file ${text} :`);

      //read txt file and convert ips to array
      const arrayIP = await readBulkIp(text);
      console.log(arrayIP);

      if(!arrayIP) {console.log(`Error file not found, please CTRL+C for closing terminal`); return;}

      //looping arrayIP
      for (const ip of arrayIP) {
        //request per-IP to reverse
          await new Promise(resolve => setTimeout(resolve, 5000));
          requestIps(ip, `${text}-result-.txt`);
      }
      setTimeout(() => {
        console.log(`Process finish overall`)
        txtMerger(arrayIP, text);
      }, arrayIP.length * 5000 + 2000);
      rl.close();
  });
}, 500);


