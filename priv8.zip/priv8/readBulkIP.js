const fs = require('fs');

const readBulkIp = async(file) => {
  // read file into a string

  if (!fs.existsSync(file)) {
    console.log(`\nFile ${file} not found\n`);
    return;
  }

  const ipList = fs.readFileSync(file, 'utf8');

  // convert string into an array
  const ipArray = ipList.split('\n').filter(ip => ip.trim() !== '');
  return ipArray;
}

module.exports = readBulkIp;
