const fs = require('fs');

const txtMerger = async(ips, filenameoutput) => {
  // Name of the output file
  const outputFile = filenameoutput+'merged-domains.txt';

  // Loop through each file and append its contents to the output file
  for (let ip of ips) {
    const inputFile = `${ip}-domains.txt`;

    // Read the contents of the input file
    const contents = fs.readFileSync(`result/`+inputFile, 'utf8');

    // Append the contents to the output file
    fs.appendFileSync(`result/`+outputFile, contents);
    fs.unlink('result/'+inputFile, (err) => {
      if (err) throw err;
      console.log('File'+inputFile+'has been deleted');
    });
  }
}

module.exports = txtMerger;